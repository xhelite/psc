package com.psc.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 表格行数据模型
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableRow {
    /** 序号 */
    private Integer index;
    /** 服务 */
    private String service;
    /** 营业 */
    private String business;
    /** 网元 */
    private String network;
    /** 操作：同步 / 一致 */
    private String action;
}
