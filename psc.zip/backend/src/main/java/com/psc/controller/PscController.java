package com.psc.controller;

import com.psc.dto.TableRow;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 服务能力前置 (PSC) Controller
 * 提供查询、同步接口
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class PscController {

    private static final String[] SERVICES = {"状态", "短信", "长权", "来显", "来电提醒", "彩铃", "流量包", "漫游"};
    private static final String[] STATUSES = {"正常", "停机", "开通", "关闭", "国内", "国际"};
    private final Random random = new Random();

    /**
     * 查询接口 - 根据手机号码随机生成表格数据
     * 供前端查询按钮调用
     */
    @GetMapping("/query")
    public ResponseEntity<List<TableRow>> query(@RequestParam(required = false) String phone) {
        List<TableRow> rows = generateRandomTableData();
        return ResponseEntity.ok(rows);
    }

    /**
     * 同步接口 - 将网元列同步为营业列内容，操作列改为"一致"
     * 供前端表格中同步操作按钮调用
     */
    @PostMapping("/sync")
    public ResponseEntity<TableRow> sync(@RequestBody TableRow row) {
        TableRow updated = new TableRow(
                row.getIndex(),
                row.getService(),
                row.getBusiness(),
                row.getBusiness(),  // 网元 = 营业
                "一致"               // 操作 = 一致（灰色）
        );
        return ResponseEntity.ok(updated);
    }

    /**
     * 随机生成表格数据，参考样例：
     * 第1行 1, 状态, 正常, 停机, 同步
     * 第2行 2, 短信, 开通, 开通, 一致（灰色）
     * 第3行 3, 长权, 国内, 国际, 同步
     * 第4行 4, 来显, 开通, 关闭, 同步
     */
    private List<TableRow> generateRandomTableData() {
        List<TableRow> rows = new ArrayList<>();
        int count = 4 + random.nextInt(4); // 4-7 行

        for (int i = 1; i <= count; i++) {
            String service = SERVICES[(i - 1) % SERVICES.length];
            String business = STATUSES[random.nextInt(STATUSES.length)];
            String network = random.nextBoolean() ? business : STATUSES[random.nextInt(STATUSES.length)];
            String action = business.equals(network) ? "一致" : "同步";
            rows.add(new TableRow(i, service, business, network, action));
        }
        return rows;
    }
}
