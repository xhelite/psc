package com.psc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 服务能力前置 (PSC) 应用入口
 */
@SpringBootApplication
public class PscApplication {

    public static void main(String[] args) {
        SpringApplication.run(PscApplication.class, args);
    }
}
