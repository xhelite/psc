<template>
  <div class="app">
    <!-- 上布局 1 份 -->
    <header class="top-layout">
      <span class="label">移网手机号码</span>
      <input
        v-model="phoneNumber"
        type="text"
        class="input"
        placeholder="请输入手机号码"
        @keyup.enter="handleQuery"
      />
      <button class="btn-query" @click="handleQuery">查询</button>
    </header>
    <!-- 下布局 10 份 -->
    <main class="bottom-layout">
      <table class="data-table">
        <thead>
          <tr>
            <th>序号</th>
            <th>服务</th>
            <th>营业</th>
            <th>网元</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in tableData" :key="row.index">
            <td>{{ row.index }}</td>
            <td>{{ row.service }}</td>
            <td>{{ row.business }}</td>
            <td>{{ row.network }}</td>
            <td>
              <button
                v-if="row.action === '同步'"
                class="btn-sync"
                @click="handleSync(row)"
              >
                同步
              </button>
              <span v-else class="text-consistent">一致</span>
            </td>
          </tr>
          <tr v-if="!loading && tableData.length === 0">
            <td colspan="5" class="empty">暂无数据，请点击查询</td>
          </tr>
        </tbody>
      </table>
      <div v-if="loading" class="loading">加载中...</div>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const phoneNumber = ref('')
const tableData = ref([])
const loading = ref(false)

const handleQuery = async () => {
  loading.value = true
  try {
    const { data } = await axios.get('/api/query', {
      params: { phone: phoneNumber.value }
    })
    tableData.value = data || []
  } catch (e) {
    console.error(e)
    tableData.value = []
  } finally {
    loading.value = false
  }
}

const handleSync = async (row) => {
  try {
    const { data } = await axios.post('/api/sync', row)
    const idx = tableData.value.findIndex(r => r.index === data.index)
    if (idx !== -1) {
      tableData.value[idx] = { ...data }
    }
  } catch (e) {
    console.error(e)
  }
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
html, body, #app {
  height: 100%;
}
.app {
  display: flex;
  flex-direction: column;
  height: 100%;
}
/* 上下布局比例 1:10 */
.top-layout {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 24px;
  background: #f5f7fa;
  border-bottom: 1px solid #e4e7ed;
}
.bottom-layout {
  flex: 10;
  padding: 24px;
  overflow: auto;
  background: #fff;
}
.label {
  font-size: 14px;
  color: #606266;
  white-space: nowrap;
}
.input {
  width: 200px;
  padding: 8px 12px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  font-size: 14px;
}
.input:focus {
  outline: none;
  border-color: #409eff;
}
.btn-query {
  padding: 8px 20px;
  background: #409eff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}
.btn-query:hover {
  background: #66b1ff;
}
.data-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}
.data-table th,
.data-table td {
  padding: 12px 16px;
  border: 1px solid #ebeef5;
  text-align: left;
}
.data-table th {
  background: #f5f7fa;
  color: #606266;
  font-weight: 600;
}
.data-table tbody tr:hover {
  background: #f5f7fa;
}
.btn-sync {
  padding: 4px 12px;
  background: #409eff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
}
.btn-sync:hover {
  background: #66b1ff;
}
/* 一致（灰色）*/
.text-consistent {
  color: #909399;
  font-size: 14px;
}
.empty {
  text-align: center;
  color: #909399;
}
.loading {
  text-align: center;
  padding: 24px;
  color: #909399;
}
</style>
